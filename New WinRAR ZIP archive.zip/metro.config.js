const {getDefaultConfig, mergeConfig} = require('@react-native/metro-config');

/**
 * Metro configuration
 * https://facebook.github.io/metro/docs/configuration
 *
 * @type {import('metro-config').MetroConfig}
 */
const config = {
  resolver: {
    blockList: [
      // Exclude Android build outputs (avoids EBUSY when Gradle holds files)
      /[/\\]android[/\\]app[/\\]build[/\\].*/,
      /[/\\]android[/\\]\.gradle[/\\].*/,
    ],
  },
};

module.exports = mergeConfig(getDefaultConfig(__dirname), config);
